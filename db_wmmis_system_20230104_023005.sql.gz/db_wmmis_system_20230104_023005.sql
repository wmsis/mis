-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: wmmis_system
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录用户名',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `type` enum('system','guest') COLLATE utf8mb4_unicode_ci DEFAULT 'guest' COMMENT '用户类型',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'17091952061','神猫','$2y$10$s87PgwkhoYDOVXDQF/GtIeyesjMm0vp0d6HVWTVl/gK9T0ST1P6Hy','system','2022-09-05 22:26:13','2022-09-05 22:26:13',NULL),(2,'13600672232','猫小鱼','$2y$10$s87PgwkhoYDOVXDQF/GtIeyesjMm0vp0d6HVWTVl/gK9T0ST1P6Hy','system','2022-09-06 23:16:14','2022-09-24 00:16:44',NULL),(3,'13738337123','christding','$2y$10$JxHDHogO2TLwPib3cp4hbuOSwj835HcKQU1CB8JRvennISFDy//XG','system','2022-09-06 23:16:14','2022-11-04 07:53:30',NULL),(4,'admin','管理员','$2y$10$s87PgwkhoYDOVXDQF/GtIeyesjMm0vp0d6HVWTVl/gK9T0ST1P6Hy','system','2022-09-06 23:16:14','2022-09-06 23:16:14',NULL),(5,'123456','123456','$2y$10$JAOMa.5sgODTuq.JVQEsDO2cUUp168alu1QPYgz8HSd4/5GVLksdG','system','2022-11-04 05:53:10','2022-11-04 05:55:00','2022-11-04 05:55:00'),(7,'456789','456789','$2y$10$eot8Z7NAVpj7y8ABIs8.w.Ci6iZk8IMv1Shkv0c48jTk0QUzi5.Ae','system','2022-11-04 05:55:36','2022-11-04 05:55:36',NULL);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenement`
--

DROP TABLE IF EXISTS `tenement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '租户名称',
  `code` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '租户编码',
  `db_name` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据库名称',
  `db_user` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据库用户名',
  `db_pwd` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据库密码',
  `memo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenement`
--

LOCK TABLES `tenement` WRITE;
/*!40000 ALTER TABLE `tenement` DISABLE KEYS */;
INSERT INTO `tenement` VALUES (1,'127.0.0.1','伟明环保股份有限公司','wmhb','wmmis_data','root','64y7nudx','伟明环保股份有限公司','2022-09-06 23:16:14','2022-09-08 02:08:15',NULL);
/*!40000 ALTER TABLE `tenement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wmmis_system'
--

--
-- Dumping routines for database 'wmmis_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-04  2:30:05
